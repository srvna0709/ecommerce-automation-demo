uBlock Origin (uBO)'s manifesto:

The **user decides** what web content is acceptable in their browser.

The uBO project does not support Adblock Plus' _"Acceptable Ads Manifesto"_ because the _"Acceptable Ads"_ marketing campaign is the business plan of a for-profit entity.

Users are the best placed to know what is or is not acceptable to them. uBO's sole purpose is to give users the means to enforce their choices.
